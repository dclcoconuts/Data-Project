<link href="./Source/css/style.css" media="screen" rel="stylesheet" type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
<script src="./Source/js/jquery.vmap.js" type="text/javascript"></script>
<script src="./Source/js/jquery.vmap.france.js" type="text/javascript"></script>
<script src="./Source/js/jquery.vmap.colorsFrance.js" type="text/javascript"></script>
<script src="./Source/js/jquery.creation.map.js" type="text/javascript"></script>